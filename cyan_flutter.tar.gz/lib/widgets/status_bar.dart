// widgets/status_bar.dart
// Bottom status bar showing connection, peers, and sync status

import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../ffi/cyan_ffi.dart';

/// Provider for status bar data (polls FFI)
final statusBarProvider = StateNotifierProvider<StatusBarNotifier, StatusBarState>((ref) {
  return StatusBarNotifier();
});

class StatusBarState {
  final bool isReady;
  final int objectCount;
  final int peerCount;
  final bool isSyncing;
  final String? lastError;
  
  const StatusBarState({
    this.isReady = false,
    this.objectCount = 0,
    this.peerCount = 0,
    this.isSyncing = false,
    this.lastError,
  });
  
  StatusBarState copyWith({
    bool? isReady,
    int? objectCount,
    int? peerCount,
    bool? isSyncing,
    String? lastError,
  }) {
    return StatusBarState(
      isReady: isReady ?? this.isReady,
      objectCount: objectCount ?? this.objectCount,
      peerCount: peerCount ?? this.peerCount,
      isSyncing: isSyncing ?? this.isSyncing,
      lastError: lastError,
    );
  }
}

class StatusBarNotifier extends StateNotifier<StatusBarState> {
  Timer? _timer;
  
  StatusBarNotifier() : super(const StatusBarState()) {
    _startPolling();
  }
  
  void _startPolling() {
    _poll(); // Initial poll
    _timer = Timer.periodic(const Duration(seconds: 2), (_) => _poll());
  }
  
  void _poll() {
    try {
      state = state.copyWith(
        isReady: CyanFFI.isReady(),
        objectCount: CyanFFI.getObjectCount(),
        peerCount: CyanFFI.getTotalPeerCount(),
      );
    } catch (e) {
      state = state.copyWith(lastError: e.toString());
    }
  }
  
  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}

class StatusBar extends ConsumerWidget {
  const StatusBar({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final status = ref.watch(statusBarProvider);
    
    return Container(
      height: 28,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      decoration: const BoxDecoration(
        color: Color(0xFF1E1F1C),
        border: Border(
          top: BorderSide(color: Color(0xFF3E3D32)),
        ),
      ),
      child: Row(
        children: [
          // Connection status
          _StatusIndicator(
            icon: status.isReady ? Icons.cloud_done : Icons.cloud_off,
            label: status.isReady ? 'Connected' : 'Disconnected',
            color: status.isReady
                ? const Color(0xFFA6E22E)
                : const Color(0xFFF92672),
          ),
          
          const SizedBox(width: 24),
          
          // Object count
          _StatusIndicator(
            icon: Icons.storage,
            label: '${status.objectCount} objects',
            color: const Color(0xFF75715E),
          ),
          
          const SizedBox(width: 24),
          
          // Peer count
          _StatusIndicator(
            icon: Icons.people,
            label: '${status.peerCount} peers',
            color: status.peerCount > 0
                ? const Color(0xFF66D9EF)
                : const Color(0xFF75715E),
          ),
          
          const Spacer(),
          
          // Sync indicator
          if (status.isSyncing) ...[
            const SizedBox(
              width: 12,
              height: 12,
              child: CircularProgressIndicator(
                strokeWidth: 2,
                valueColor: AlwaysStoppedAnimation<Color>(Color(0xFF66D9EF)),
              ),
            ),
            const SizedBox(width: 8),
            const Text(
              'Syncing...',
              style: TextStyle(
                fontSize: 11,
                color: Color(0xFF66D9EF),
              ),
            ),
          ] else ...[
            const Icon(
              Icons.check_circle,
              size: 14,
              color: Color(0xFFA6E22E),
            ),
            const SizedBox(width: 4),
            const Text(
              'Synced',
              style: TextStyle(
                fontSize: 11,
                color: Color(0xFFA6E22E),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _StatusIndicator extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  
  const _StatusIndicator({
    required this.icon,
    required this.label,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: color),
        const SizedBox(width: 4),
        Text(
          label,
          style: TextStyle(
            fontSize: 11,
            color: color,
          ),
        ),
      ],
    );
  }
}
