// widgets/icon_rail.dart
// RustRover-style vertical icon rail with navigation modes, console toggle, and DMs

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/navigation_provider.dart';

/// Navigation modes matching Swift IconRail
enum NavigationMode {
  explorer('Explorer', Icons.description_outlined, '⌘1'),
  boards('Boards', Icons.dashboard_outlined, '⌘2'),
  chat('Chat', Icons.forum_outlined, '⌘3'),
  events('Events', Icons.hub_outlined, '⌘4');

  final String label;
  final IconData icon;
  final String shortcut;
  const NavigationMode(this.label, this.icon, this.shortcut);
}

class IconRail extends ConsumerStatefulWidget {
  const IconRail({super.key});

  @override
  ConsumerState<IconRail> createState() => _IconRailState();
}

class _IconRailState extends ConsumerState<IconRail> {
  bool _showConsole = false;
  bool _showSplit = false;
  
  @override
  Widget build(BuildContext context) {
    final currentMode = ref.watch(navigationModeProvider);
    
    return Container(
      width: 56,
      color: const Color(0xFF1E1E1E),
      child: Column(
        children: [
          const SizedBox(height: 12),
          
          // Navigation modes (top section)
          ...NavigationMode.values.map((mode) => _IconRailButton(
            icon: mode.icon,
            label: mode.label,
            isSelected: currentMode == mode,
            shortcut: mode.shortcut,
            showLabel: true,
            onTap: () => ref.read(navigationModeProvider.notifier).setMode(mode),
          )),
          
          // Divider
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Container(height: 1, color: const Color(0xFF2A2A2A), margin: const EdgeInsets.symmetric(horizontal: 8)),
          ),
          
          // Console toggle
          _IconRailButton(
            icon: Icons.terminal,
            label: 'Console',
            isSelected: _showConsole,
            shortcut: '⌘5',
            accentColor: const Color(0xFF66D9EF),
            showLabel: true,
            onTap: () => setState(() => _showConsole = !_showConsole),
          ),
          
          // DMs button
          _DMsButton(onTap: () {
            // Show DMs popover
          }),
          
          const Spacer(),
          
          // Bottom section: Actions
          _IconRailButton(
            icon: _showSplit ? Icons.vertical_split : Icons.vertical_split_outlined,
            label: 'Split',
            isSelected: _showSplit,
            shortcut: '⌘\\',
            showLabel: true,
            onTap: () => setState(() => _showSplit = !_showSplit),
          ),
          
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Container(height: 1, color: const Color(0xFF2A2A2A), margin: const EdgeInsets.symmetric(horizontal: 8)),
          ),
          
          // New Board
          _IconRailButton(
            icon: Icons.dashboard,
            label: 'New Board',
            isSelected: false,
            shortcut: '⌘N',
            accentColor: const Color(0xFF66D9EF),
            showLabel: false,
            badgeIcon: Icons.add_circle,
            onTap: () {
              // Create new board
            },
          ),
          
          // New Chat
          _IconRailButton(
            icon: Icons.chat_bubble_outline,
            label: 'New Chat',
            isSelected: false,
            shortcut: '⌘⇧C',
            accentColor: const Color(0xFFA6E22E),
            showLabel: false,
            badgeIcon: Icons.add_circle,
            onTap: () {
              // Create new chat
            },
          ),
          
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 8),
            child: Container(height: 1, color: const Color(0xFF2A2A2A), margin: const EdgeInsets.symmetric(horizontal: 8)),
          ),
          
          // Settings
          _IconRailButton(
            icon: Icons.settings_outlined,
            label: 'Settings',
            isSelected: false,
            shortcut: '⌘,',
            showLabel: false,
            onTap: () {
              // Show settings
            },
          ),
          
          // Profile
          _IconRailButton(
            icon: Icons.account_circle_outlined,
            label: 'Profile',
            isSelected: false,
            shortcut: '⌘⇧P',
            showLabel: false,
            onTap: () {
              ref.read(navigationModeProvider.notifier).showProfile();
            },
          ),
          
          const SizedBox(height: 12),
        ],
      ),
    );
  }
}

class _IconRailButton extends StatefulWidget {
  final IconData icon;
  final String label;
  final bool isSelected;
  final String shortcut;
  final Color accentColor;
  final bool showLabel;
  final IconData? badgeIcon;
  final VoidCallback onTap;

  const _IconRailButton({
    required this.icon,
    required this.label,
    required this.isSelected,
    this.shortcut = '',
    this.accentColor = const Color(0xFFA6E22E),
    this.showLabel = true,
    this.badgeIcon,
    required this.onTap,
  });

  @override
  State<_IconRailButton> createState() => _IconRailButtonState();
}

class _IconRailButtonState extends State<_IconRailButton> {
  bool _isHovered = false;

  Color get _iconColor {
    if (widget.isSelected) return widget.accentColor;
    if (_isHovered) return const Color(0xFFCCCCCC);
    return const Color(0xFF808080);
  }

  Color get _labelColor {
    if (widget.isSelected) return widget.accentColor;
    return const Color(0xFF808080);
  }

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: '${widget.label} (${widget.shortcut})',
      waitDuration: const Duration(milliseconds: 500),
      child: MouseRegion(
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        child: GestureDetector(
          onTap: widget.onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      width: 44,
                      height: 28,
                      decoration: BoxDecoration(
                        color: widget.isSelected
                            ? widget.accentColor.withValues(alpha: 0.15)
                            : (_isHovered ? const Color(0xFF2A2A2A) : Colors.transparent),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Icon(
                        widget.icon,
                        size: 18,
                        color: _iconColor,
                      ),
                    ),
                    if (widget.badgeIcon != null)
                      Positioned(
                        right: -2,
                        bottom: -2,
                        child: Icon(
                          widget.badgeIcon,
                          size: 10,
                          color: _iconColor,
                        ),
                      ),
                  ],
                ),
                if (widget.showLabel) ...[
                  const SizedBox(height: 2),
                  Text(
                    widget.label,
                    style: TextStyle(
                      fontSize: 9,
                      fontWeight: FontWeight.w500,
                      color: _labelColor,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _DMsButton extends StatefulWidget {
  final VoidCallback onTap;
  
  const _DMsButton({required this.onTap});

  @override
  State<_DMsButton> createState() => _DMsButtonState();
}

class _DMsButtonState extends State<_DMsButton> {
  bool _isHovered = false;
  int _unreadCount = 0; // TODO: Wire to actual DM manager

  @override
  Widget build(BuildContext context) {
    return Tooltip(
      message: 'Direct Messages (⌘D)',
      child: MouseRegion(
        onEnter: (_) => setState(() => _isHovered = true),
        onExit: (_) => setState(() => _isHovered = false),
        child: GestureDetector(
          onTap: widget.onTap,
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 4),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Container(
                      width: 44,
                      height: 28,
                      decoration: BoxDecoration(
                        color: _isHovered ? const Color(0xFF2A2A2A) : Colors.transparent,
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Icon(
                        Icons.mark_chat_unread,
                        size: 16,
                        color: _isHovered ? const Color(0xFFF92672) : const Color(0xFF808080),
                      ),
                    ),
                    if (_unreadCount > 0)
                      Positioned(
                        right: 2,
                        top: -4,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 1),
                          decoration: BoxDecoration(
                            color: const Color(0xFFF92672),
                            borderRadius: BorderRadius.circular(6),
                          ),
                          child: Text(
                            _unreadCount > 99 ? '99+' : '$_unreadCount',
                            style: const TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 2),
                const Text(
                  'DMs',
                  style: TextStyle(
                    fontSize: 9,
                    fontWeight: FontWeight.w500,
                    color: Color(0xFF808080),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
