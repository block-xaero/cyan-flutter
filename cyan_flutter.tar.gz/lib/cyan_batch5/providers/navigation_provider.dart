// providers/navigation_provider.dart
// Navigation state with modes matching Swift IconRail

import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../widgets/icon_rail.dart';

/// Current navigation state
class NavigationState {
  final NavigationMode mode;
  final bool showProfile;
  final bool showDebug;
  
  const NavigationState({
    this.mode = NavigationMode.explorer,
    this.showProfile = false,
    this.showDebug = false,
  });
  
  NavigationState copyWith({
    NavigationMode? mode,
    bool? showProfile,
    bool? showDebug,
  }) {
    return NavigationState(
      mode: mode ?? this.mode,
      showProfile: showProfile ?? this.showProfile,
      showDebug: showDebug ?? this.showDebug,
    );
  }
}

/// Provider for navigation mode
final navigationModeProvider = StateNotifierProvider<NavigationModeNotifier, NavigationMode>((ref) {
  return NavigationModeNotifier();
});

class NavigationModeNotifier extends StateNotifier<NavigationMode> {
  NavigationModeNotifier() : super(NavigationMode.explorer);
  
  void setMode(NavigationMode mode) {
    state = mode;
  }
  
  void showProfile() {
    // TODO: Navigate to profile
  }
}

/// Legacy provider for backward compatibility
enum NavSection { home, search, starred, profile, debug }

final navigationProvider = StateNotifierProvider<NavigationNotifier, NavSection>((ref) {
  return NavigationNotifier();
});

class NavigationNotifier extends StateNotifier<NavSection> {
  NavigationNotifier() : super(NavSection.home);
  
  void setSection(NavSection section) {
    state = section;
  }
}
