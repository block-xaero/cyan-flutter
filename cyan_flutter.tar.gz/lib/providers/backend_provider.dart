// providers/backend_provider.dart
// Provider for backend initialization and status

import 'dart:async';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import '../ffi/ffi_helpers.dart';
import '../ffi/component_bridge.dart';

/// Backend initialization status
enum BackendStatus {
  uninitialized,
  initializing,
  ready,
  error,
}

/// Backend state
class BackendState {
  final BackendStatus status;
  final String? nodeId;
  final String? errorMessage;
  final int objectCount;
  final int peerCount;
  
  const BackendState({
    this.status = BackendStatus.uninitialized,
    this.nodeId,
    this.errorMessage,
    this.objectCount = 0,
    this.peerCount = 0,
  });
  
  BackendState copyWith({
    BackendStatus? status,
    String? nodeId,
    String? errorMessage,
    int? objectCount,
    int? peerCount,
  }) {
    return BackendState(
      status: status ?? this.status,
      nodeId: nodeId ?? this.nodeId,
      errorMessage: errorMessage ?? this.errorMessage,
      objectCount: objectCount ?? this.objectCount,
      peerCount: peerCount ?? this.peerCount,
    );
  }
  
  bool get isReady => status == BackendStatus.ready;
}

/// Provider for backend state
final backendProvider = StateNotifierProvider<BackendNotifier, BackendState>((ref) {
  return BackendNotifier();
});

/// Notifier for backend state
class BackendNotifier extends StateNotifier<BackendState> {
  Timer? _statusTimer;
  
  BackendNotifier() : super(const BackendState());
  
  /// Initialize backend with identity
  Future<bool> initialize({
    required String secretKeyHex,
    String relayUrl = 'https://quic.dev.cyan.blockxaero.io',
    String discoveryKey = 'cyan-dev',
  }) async {
    if (state.status == BackendStatus.initializing) {
      return false;
    }
    
    state = state.copyWith(status: BackendStatus.initializing);
    
    try {
      // Get document directory for database
      final appDir = await getApplicationDocumentsDirectory();
      final dbPath = '${appDir.path}/cyan.db';
      final dataDir = '${appDir.path}/cyan_data';
      
      print('📁 Initializing backend...');
      print('   DB path: $dbPath');
      print('   Data dir: $dataDir');
      
      // Initialize with identity
      final success = CyanFFI.initWithIdentity(
        dbPath: dbPath,
        secretKeyHex: secretKeyHex,
        relayUrl: relayUrl,
        discoveryKey: discoveryKey,
      );
      
      if (!success) {
        state = state.copyWith(
          status: BackendStatus.error,
          errorMessage: 'Failed to initialize backend',
        );
        return false;
      }
      
      // Set data directory
      CyanFFI.setDataDir(appDir.path);
      
      // Wait for backend to be ready
      var attempts = 0;
      while (!CyanFFI.isReady() && attempts < 50) {
        await Future.delayed(const Duration(milliseconds: 100));
        attempts++;
      }
      
      if (!CyanFFI.isReady()) {
        state = state.copyWith(
          status: BackendStatus.error,
          errorMessage: 'Backend timeout',
        );
        return false;
      }
      
      // Get node ID
      final nodeId = CyanFFI.getNodeId();
      
      state = state.copyWith(
        status: BackendStatus.ready,
        nodeId: nodeId,
      );
      
      // Start status polling
      _startStatusPolling();
      
      print('✅ Backend ready, node ID: ${nodeId?.substring(0, 16)}...');
      return true;
      
    } catch (e) {
      state = state.copyWith(
        status: BackendStatus.error,
        errorMessage: e.toString(),
      );
      return false;
    }
  }
  
  /// Check if backend is ready (for quick status check)
  bool checkReady() {
    return CyanFFI.isReady();
  }
  
  /// Update status (called periodically)
  void _updateStatus() {
    if (!CyanFFI.isReady()) return;
    
    final objectCount = CyanFFI.getObjectCount();
    final peerCount = CyanFFI.getTotalPeerCount();
    
    if (objectCount != state.objectCount || peerCount != state.peerCount) {
      state = state.copyWith(
        objectCount: objectCount,
        peerCount: peerCount,
      );
    }
  }
  
  /// Start periodic status polling
  void _startStatusPolling() {
    _statusTimer?.cancel();
    _statusTimer = Timer.periodic(
      const Duration(seconds: 2),
      (_) => _updateStatus(),
    );
  }
  
  /// Seed demo data if database is empty
  bool seedDemoIfEmpty() {
    return CyanFFI.seedDemoIfEmpty();
  }
  
  /// Send a command and poll result (for testing)
  Future<String?> testSendCommand(String component, String json) async {
    final success = CyanFFI.sendCommand(component, json);
    if (!success) return null;
    
    // Wait a bit for response
    await Future.delayed(const Duration(milliseconds: 200));
    
    return CyanFFI.pollEvents(component);
  }
  
  /// Shutdown backend
  void shutdown() {
    _statusTimer?.cancel();
    // CyanFFI.shutdown(); // TODO: add to Rust
    state = const BackendState();
  }
  
  @override
  void dispose() {
    _statusTimer?.cancel();
    super.dispose();
  }
}

/// Convenience providers
final backendReadyProvider = Provider<bool>((ref) {
  return ref.watch(backendProvider).isReady;
});

final backendNodeIdProvider = Provider<String?>((ref) {
  return ref.watch(backendProvider).nodeId;
});

final objectCountProvider = Provider<int>((ref) {
  return ref.watch(backendProvider).objectCount;
});

final peerCountProvider = Provider<int>((ref) {
  return ref.watch(backendProvider).peerCount;
});
