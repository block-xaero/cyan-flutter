// providers/chat_provider.dart
// Chat state - messages for a board

import 'dart:async';
import 'dart:convert';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../ffi/cyan_ffi.dart';
import '../ffi/component_bridge.dart';
import '../models/chat_message.dart';

class ChatState {
  final List<ChatMessage> messages;
  final bool isLoading;
  final String? error;
  
  const ChatState({
    this.messages = const [],
    this.isLoading = false,
    this.error,
  });
  
  ChatState copyWith({
    List<ChatMessage>? messages,
    bool? isLoading,
    String? error,
  }) {
    return ChatState(
      messages: messages ?? this.messages,
      isLoading: isLoading ?? this.isLoading,
      error: error,
    );
  }
}

/// Chat provider per board (family)
final chatProvider = StateNotifierProvider.family<ChatNotifier, ChatState, String>((ref, boardId) {
  return ChatNotifier(boardId);
});

class ChatNotifier extends StateNotifier<ChatState> {
  final String boardId;
  final _bridge = ComponentBridge<ChatCommand, ChatEvent>(
    componentName: 'chat_panel',
    eventParser: ChatEvent.fromJson,
  );
  
  ChatNotifier(this.boardId) : super(const ChatState()) {
    _initialize();
  }
  
  void _initialize() {
    _bridge.start();
    _bridge.events.listen(_handleEvent);
  }
  
  void _handleEvent(ChatEvent event) {
    if (event.isMessage) {
      // Add new message
      final newMessage = event.toMessage();
      if (newMessage != null) {
        final messages = [...state.messages, newMessage];
        state = state.copyWith(messages: messages);
      }
    } else if (event.isChatHistory) {
      // Load full history
      state = state.copyWith(
        messages: event.messages,
        isLoading: false,
      );
    } else if (event.isError) {
      state = state.copyWith(
        error: event.errorMessage,
        isLoading: false,
      );
    }
  }
  
  void loadHistory() {
    state = state.copyWith(isLoading: true);
    _bridge.send(ChatCommand.loadHistory(boardId));
  }
  
  void sendMessage(String text) {
    _bridge.send(ChatCommand.sendMessage(boardId, text));
    
    // Optimistically add message
    final myProfile = CyanFFI.getMyProfile();
    String displayName = 'Me';
    try {
      final profile = jsonDecode(myProfile as String) as Map<String, dynamic>;
      displayName = profile['displayName'] as String? ?? 'Me';
    } catch (_) {}

    final optimisticMessage = ChatMessage(
      id: DateTime.now().millisecondsSinceEpoch.toString(),
      boardId: boardId,
      senderId: 'me',
      senderName: displayName,
      text: text,
      timestamp: DateTime.now(),
      isMe: true,
    );
    
    state = state.copyWith(
      messages: [...state.messages, optimisticMessage],
    );
  }
  
  @override
  void dispose() {
    _bridge.dispose();
    super.dispose();
  }
}

// Chat commands
class ChatCommand implements ComponentCommand {
  final String type;
  final Map<String, dynamic>? data;
  
  ChatCommand._(this.type, [this.data]);
  
  factory ChatCommand.loadHistory(String boardId) =>
      ChatCommand._('LoadChatHistory', {'board_id': boardId});
  
  factory ChatCommand.sendMessage(String boardId, String text) =>
      ChatCommand._('SendMessage', {'board_id': boardId, 'text': text});
  
  @override
  String toJson() => jsonEncode({'type': type, ...?data});
  
  @override
  String? get syncDescription => type;
}

// Chat events
class ChatEvent implements ComponentEvent {
  final String type;
  final Map<String, dynamic> data;
  
  ChatEvent._(this.type, this.data);
  
  static ChatEvent? fromJson(String json) {
    try {
      final map = jsonDecode(json) as Map<String, dynamic>;
      final type = map['type'] as String?;
      if (type == null) return null;
      return ChatEvent._(type, map);
    } catch (e) {
      return null;
    }
  }
  
  bool get isMessage => type == 'Message';
  bool get isChatHistory => type == 'ChatHistory';
  bool get isError => type == 'Error';
  
  String? get errorMessage => data['message'] as String?;
  
  ChatMessage? toMessage() {
    try {
      return ChatMessage(
        id: data['id'] as String? ?? '',
        boardId: data['board_id'] as String? ?? '',
        senderId: data['sender_id'] as String? ?? '',
        senderName: data['sender_name'] as String? ?? 'Unknown',
        senderColor: data['sender_color'] as String?,
        text: data['text'] as String? ?? '',
        timestamp: DateTime.tryParse(data['timestamp'] as String? ?? '') ?? DateTime.now(),
        isMe: data['is_me'] as bool? ?? false,
      );
    } catch (_) {
      return null;
    }
  }
  
  List<ChatMessage> get messages {
    final messagesData = data['messages'] as List<dynamic>? ?? [];
    return messagesData.map((m) {
      final msg = m as Map<String, dynamic>;
      return ChatMessage(
        id: msg['id'] as String? ?? '',
        boardId: msg['board_id'] as String? ?? '',
        senderId: msg['sender_id'] as String? ?? '',
        senderName: msg['sender_name'] as String? ?? 'Unknown',
        senderColor: msg['sender_color'] as String?,
        text: msg['text'] as String? ?? '',
        timestamp: DateTime.tryParse(msg['timestamp'] as String? ?? '') ?? DateTime.now(),
        isMe: msg['is_me'] as bool? ?? false,
      );
    }).toList();
  }
}
